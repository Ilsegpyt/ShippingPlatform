﻿using FluentValidation;

namespace Content.Application.Content.UpdateContent;

public sealed class UpdateContentCommandValidator
    : AbstractValidator<UpdateContentCommand>
{
    public UpdateContentCommandValidator()
    {
        RuleFor(x => x.Id)
            .NotEmpty();

        RuleFor(x => x.Title)
            .NotEmpty()
            .MaximumLength(200);

        RuleFor(x => x.Type)
            .IsInEnum();

        RuleFor(x => x.Body)
            .MaximumLength(100000);

        RuleFor(x => x.FeaturedImage)
            .MaximumLength(1000);

        RuleFor(x => x.LinkUrl)
            .MaximumLength(2000);

        RuleFor(x => x.Category)
            .MaximumLength(100);

        // Category
        When(x => x.Type == Domain.Entities.ContentType.Category, () =>
        {
            RuleFor(x => x.Body)
                .Empty()
                .WithMessage("Category content cannot have a body.");

            RuleFor(x => x.FeaturedImage)
                .Empty()
                .WithMessage("Category content cannot have a featured image.");

            RuleFor(x => x.LinkUrl)
                .Empty()
                .WithMessage("Category content cannot have a link URL.");

            RuleFor(x => x.Category)
                .Empty()
                .WithMessage("Category content cannot have a category.");

            RuleFor(x => x.PublishedAt)
                .Null()
                .WithMessage("Category content cannot have a published date.");
        });

        // Page
        When(x => x.Type == Domain.Entities.ContentType.Page, () =>
        {
            RuleFor(x => x.Body)
                .NotEmpty()
                .WithMessage("Body is required for Page content.");

            RuleFor(x => x.FeaturedImage)
                .Empty()
                .WithMessage("Page content cannot have a featured image.");

            RuleFor(x => x.LinkUrl)
                .Empty()
                .WithMessage("Page content cannot have a link URL.");

            RuleFor(x => x.Category)
                .Empty()
                .WithMessage("Page content cannot have a category.");

            RuleFor(x => x.PublishedAt)
                .Null()
                .WithMessage("Page content cannot have a published date.");
        });

        // Post
        When(x => x.Type == Domain.Entities.ContentType.Post, () =>
        {
            RuleFor(x => x.Body)
                .NotEmpty()
                .WithMessage("Body is required for Post content.");

            RuleFor(x => x.FeaturedImage)
                .NotEmpty()
                .WithMessage("Featured image is required for Post content.");

            RuleFor(x => x.LinkUrl)
                .Empty()
                .WithMessage("Post content cannot have a link URL.");

            RuleFor(x => x.Category)
                .NotEmpty()
                .WithMessage("Category is required for Post content.");

            RuleFor(x => x.PublishedAt)
                .NotNull()
                .WithMessage("Published date is required for Post content.");
        });

        // Link
        When(x => x.Type == Domain.Entities.ContentType.Link, () =>
        {
            RuleFor(x => x.Body)
                .Empty()
                .WithMessage("Link content cannot have a body.");

            RuleFor(x => x.FeaturedImage)
                .Empty()
                .WithMessage("Link content cannot have a featured image.");

            RuleFor(x => x.LinkUrl)
                .NotEmpty()
                .WithMessage("Link URL is required for Link content.");

            RuleFor(x => x.Category)
                .Empty()
                .WithMessage("Link content cannot have a category.");

            RuleFor(x => x.PublishedAt)
                .Null()
                .WithMessage("Link content cannot have a published date.");
        });
    }
}