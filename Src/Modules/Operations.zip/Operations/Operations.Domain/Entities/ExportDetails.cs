﻿
using BuildingBlocks.Domain;
using Operations.Domain.Enums;
using Operations.Domain.Common;

namespace Operations.Domain.Entities;

public class ExportDetails : Entity<Guid>
{
    public Guid OperationId { get; private set; }

    public ClearanceType ClearanceType { get; private set; }

    public string BookingNumber { get; private set; } = null!;

    public Guid POLId { get; private set; }

    public Port POL { get; private set; } = null!;

    public Guid? POWId { get; private set; }

    public Port? POW { get; private set; }

    public DateOnly? CutOffDate { get; private set; }

    public string? Customs { get; private set; }

    public Operation Operation { get; private set; } = null!;

    private ExportDetails()
    {
    }

    public void UpdateCustoms(string? customs)
    {
        Customs = string.IsNullOrWhiteSpace(customs)
            ? null
            : customs.Trim();
    }

    public ExportDetails(
        ClearanceType clearanceType,
        string bookingNumber,
        Guid polId,
        Guid? powId,
        DateOnly? cutOffDate)
    {
        ClearanceType = clearanceType;
        BookingNumber = IdentifierNormalizer.Normalize(bookingNumber) ?? string.Empty;
        POLId = polId;
        POWId = powId;
        CutOffDate = cutOffDate;
    }
}
