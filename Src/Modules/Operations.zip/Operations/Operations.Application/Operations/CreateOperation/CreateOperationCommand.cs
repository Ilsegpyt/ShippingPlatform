﻿using BuildingBlocks.Application;
using MediatR;
using Operations.Domain.Enums;

namespace Operations.Application.Operations.CreateOperation;

public sealed record CreateOperationCommand(
    // Common
    Guid ClientId,
    Guid ShippingLineId,
    OperationType OperationType,
    int NumberOfContainers,

    // Import
    string? MBLNumber,
    string? Destination,
    Guid? PODId,
    DateOnly? FreeTimeTill,
    DateOnly? RequiredOffloadingDate,
    TimeOnly? RequiredOffloadingTime,

    // Export
    ClearanceType? ClearanceType,
    string? BookingNumber,
    Guid? POLId,
    Guid? POWId,
    DateOnly? CutOffDate,
    string? ExportDestination

) : IRequest<Result<Guid>>;