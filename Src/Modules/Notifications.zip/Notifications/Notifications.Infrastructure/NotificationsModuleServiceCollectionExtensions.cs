﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Notifications.Application.Abstractions;
using Notifications.Application.Options;
using Notifications.Application.Services;
using Notifications.Infrastructure.Email;
using Notifications.Infrastructure.Persistence;
using Notifications.Infrastructure.Persistence.Repositories;

namespace Notifications.Infrastructure;

public static class NotificationsModuleServiceCollectionExtensions
{
    public static IServiceCollection AddNotificationsInfrastructure(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.AddDbContext<NotificationsDbContext>(options =>
            options.UseSqlServer(
                configuration.GetConnectionString("NotificationsDb")));

        services.AddOptions<EmailOptions>()
            .Configure(options =>
            {
                options.SmtpHost = configuration["Email:SmtpHost"] ?? "";
                options.SmtpPort = int.Parse(
                    configuration["Email:SmtpPort"] ?? "587");
                options.Username = configuration["Email:Username"] ?? "";
                options.Password = configuration["Email:Password"] ?? "";
                options.FromEmail = configuration["Email:FromEmail"] ?? "";
                options.FromName = configuration["Email:FromName"] ?? "";
            })
            .ValidateDataAnnotations()
            .ValidateOnStart();

        services.AddOptions<NotificationOptions>()
            .Configure(options =>
            {
                options.FrontendBaseUrl =
                    configuration["Notifications:FrontendBaseUrl"] ?? "";
            })
            .Validate(
                options => !string.IsNullOrWhiteSpace(options.FrontendBaseUrl),
                "Notifications:FrontendBaseUrl is required.")
            .ValidateOnStart();

        services.AddScoped<IEmailSender, EmailSender>();
        services.AddScoped<INotificationRepository, NotificationRepository>();
        services.AddScoped<IEmailOutboxRepository, EmailOutboxRepository>();
        services.AddScoped<NotificationQueries>();

        services.AddScoped<INotificationsUnitOfWork>(
            sp => sp.GetRequiredService<NotificationsDbContext>());

        return services;
    }
}