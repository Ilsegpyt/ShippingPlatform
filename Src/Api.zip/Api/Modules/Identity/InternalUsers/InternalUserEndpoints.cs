﻿using BuildingBlocks.Application;
using Identity.Api.InternalUsers;
using Identity.Application.InternalUsers.ChangeInternalUserStatus;
using Identity.Application.InternalUsers.CreateInternalUser;
using Identity.Application.InternalUsers.DeleteInternalUser;
using Identity.Application.InternalUsers.GetInternalUsers;
using Identity.Application.InternalUsers.UpdateInternalUserEmail;
using Identity.Application.InternalUsers.UpdateInternalUserProfile;
using Identity.Domain.ValueObjects;
using Identity.Infrastructure.Authorization;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace Api.Modules.Identity.InternalUsers;

public static class InternalUserEndpoints
{
    public static void Map(IEndpointRouteBuilder app)
    {
        var users = app.MapGroup("/api/internal-users")
            .WithTags("InternalUsers");

        MapCreate(users);
        MapUpdateProfile(users);
        MapUpdateEmail(users);
        MapDelete(users);
        MapGetAll(users);
        MapChangeStatus(users);

    }

    private static void MapCreate(IEndpointRouteBuilder users)
    {
        users.MapPost("/", async (
            CreateInternalUserCommand command,
            ISender sender,
            CancellationToken ct) =>
        {
            var result = await sender.Send(command, ct);

            return result.IsSuccess
                ? Results.Ok(result.Value)
                : Results.BadRequest(result.Error);
        })
        .RequirePermission(PermissionCatalog.UsersCreate);
    }
    private static void MapUpdateProfile(IEndpointRouteBuilder users)
    {
        users.MapPut("/{id:guid}", async (
            Guid id,
            UpdateInternalUserProfileRequestBody body,
            ISender sender,
            CancellationToken ct) =>
        {
            var result = await sender.Send(
                new UpdateInternalUserProfileCommand(
                    id,
                    body.Name,
                    body.Phone),
                ct);

            return result.IsSuccess
                ? Results.NoContent()
                : Results.BadRequest(result.Error);
        })
        .RequirePermission(PermissionCatalog.UsersEdit);
    }
    private static void MapUpdateEmail(IEndpointRouteBuilder users)
    {
        users.MapPut("/{id:guid}/email", async (
            Guid id,
            UpdateInternalUserEmailRequestBody body,
            ISender sender,
            CancellationToken ct) =>
        {
            var result = await sender.Send(
                new UpdateInternalUserEmailCommand(
                    id,
                    body.Email),
                ct);

            return result.IsSuccess
                ? Results.NoContent()
                : Results.BadRequest(result.Error);
        })
        .RequirePermission(PermissionCatalog.UsersEdit);
    }
    private static void MapDelete(IEndpointRouteBuilder group)
    {
        group.MapDelete("/", async (
            [FromBody] DeleteInternalUsersCommand command,
            ISender sender,
            CancellationToken ct) =>
        {
            var result = await sender.Send(command, ct);

            return result.IsSuccess
                ? Results.NoContent()
                : Results.BadRequest(result.Error);
        })
            .RequirePermission(PermissionCatalog.UsersDelete);
    }
    private static void MapGetAll(IEndpointRouteBuilder users)
    {
        users.MapGet("/", async (
            [AsParameters] PaginationRequest pagination,
            ISender sender,
            CancellationToken ct) =>
        {
            var result = await sender.Send(
                new GetInternalUsersQuery(pagination),
                ct);

            return Results.Ok(result);
        })
        .RequirePermission(PermissionCatalog.UsersView);
    }
    private static void MapChangeStatus(IEndpointRouteBuilder users)
    {
        users.MapPut("/{id:guid}/activate", async (
            Guid id,
            ISender sender,
            CancellationToken ct) =>
        {
            var result = await sender.Send(
                new ChangeInternalUserStatusCommand(
                    id,
                    InternalUserStatusAction.Activate),
                ct);

            return result.IsSuccess
                ? Results.NoContent()
                : Results.BadRequest(result.Error);
        })
        .RequirePermission(PermissionCatalog.UsersEdit);

        users.MapPut("/{id:guid}/deactivate", async (
            Guid id,
            ISender sender,
            CancellationToken ct) =>
        {
            var result = await sender.Send(
                new ChangeInternalUserStatusCommand(
                    id,
                    InternalUserStatusAction.Deactivate),
                ct);

            return result.IsSuccess
                ? Results.NoContent()
                : Results.BadRequest(result.Error);
        })
        .RequirePermission(PermissionCatalog.UsersEdit);
    }

}